package com.ren.mapper;

import java.util.List;

import com.ren.model.Department;

public interface DepartmentMapper {

	public String getNameById(String id);

	public List<Department> getAllDepartment(String name);

	public String getIdByName(String departmentname);
	
	public List<Department> getDepartmentByNameLike(String name,int pageBegin,int pageSize);

	public void deleteDepartment(String departmentid);
	
	public Department selectDepartmentById(String departmentid);

	public void saveDepartment(Department department);
}
