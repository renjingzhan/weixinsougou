package com.ren.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ren.mapper.UserMapper;
import com.ren.model.User;
import com.ren.service.LoginService;
import com.ren.util.ValueUtil;

@Service
public class LoginServiceImpl implements LoginService{
	
	@Autowired
	private  UserMapper userMapper;

	public String login(User user) {
		
		String password=userMapper.getPasswordByName(user.getUserName());
		
		if(password!=null&&password.equals(user.getPassword())){
			return ValueUtil.SUCCESS;
		}
		return ValueUtil.FAILURE;
	}

}
