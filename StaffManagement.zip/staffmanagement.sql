/*
Navicat MySQL Data Transfer

Source Server         : MYSQL
Source Server Version : 50717
Source Host           : localhost:3306
Source Database       : staffmanagement

Target Server Type    : MYSQL
Target Server Version : 50717
File Encoding         : 65001

Date: 2017-12-20 10:39:04
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for dailycommit
-- ----------------------------
DROP TABLE IF EXISTS `dailycommit`;
CREATE TABLE `dailycommit` (
  `day` varchar(255) NOT NULL,
  `iscommit` int(11) DEFAULT NULL,
  PRIMARY KEY (`day`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of dailycommit
-- ----------------------------
INSERT INTO `dailycommit` VALUES ('2017-09-12', '1');
INSERT INTO `dailycommit` VALUES ('2017-09-24', '1');
INSERT INTO `dailycommit` VALUES ('2017-09-26', '1');
INSERT INTO `dailycommit` VALUES ('2017-09-27', '1');
INSERT INTO `dailycommit` VALUES ('2017-09-28', '1');
INSERT INTO `dailycommit` VALUES ('2017-10-11', '1');

-- ----------------------------
-- Table structure for department
-- ----------------------------
DROP TABLE IF EXISTS `department`;
CREATE TABLE `department` (
  `departmentid` varchar(255) NOT NULL,
  `departmentname` varchar(255) DEFAULT NULL,
  `duty` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`departmentid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of department
-- ----------------------------
INSERT INTO `department` VALUES ('101', '后勤部', '无');
INSERT INTO `department` VALUES ('102', '实施部', '负责任务实施');
INSERT INTO `department` VALUES ('103', '财务部', '掌管财政大权');
INSERT INTO `department` VALUES ('104', '技术部', '技术研发');

-- ----------------------------
-- Table structure for kaoqin
-- ----------------------------
DROP TABLE IF EXISTS `kaoqin`;
CREATE TABLE `kaoqin` (
  `staffid` varchar(255) NOT NULL,
  `day` varchar(255) NOT NULL,
  `isonduty` int(255) DEFAULT NULL,
  PRIMARY KEY (`staffid`,`day`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of kaoqin
-- ----------------------------
INSERT INTO `kaoqin` VALUES ('1001', '2017-09-12', '1');
INSERT INTO `kaoqin` VALUES ('1001', '2017-09-24', '1');
INSERT INTO `kaoqin` VALUES ('1001', '2017-09-26', '1');
INSERT INTO `kaoqin` VALUES ('1001', '2017-09-27', '0');
INSERT INTO `kaoqin` VALUES ('1001', '2017-09-28', '1');
INSERT INTO `kaoqin` VALUES ('1001', '2017-10-11', '1');
INSERT INTO `kaoqin` VALUES ('1002', '2017-09-12', '0');
INSERT INTO `kaoqin` VALUES ('1002', '2017-09-24', '1');
INSERT INTO `kaoqin` VALUES ('1002', '2017-09-26', '0');
INSERT INTO `kaoqin` VALUES ('1002', '2017-09-27', '1');
INSERT INTO `kaoqin` VALUES ('1002', '2017-09-28', '1');
INSERT INTO `kaoqin` VALUES ('1002', '2017-10-11', '1');
INSERT INTO `kaoqin` VALUES ('1003', '2017-09-12', '1');
INSERT INTO `kaoqin` VALUES ('1003', '2017-09-24', '1');
INSERT INTO `kaoqin` VALUES ('1003', '2017-09-26', '1');
INSERT INTO `kaoqin` VALUES ('1003', '2017-09-27', '1');
INSERT INTO `kaoqin` VALUES ('1003', '2017-09-28', '1');
INSERT INTO `kaoqin` VALUES ('1003', '2017-10-11', '1');
INSERT INTO `kaoqin` VALUES ('1004', '2017-09-12', '1');
INSERT INTO `kaoqin` VALUES ('1004', '2017-09-24', '1');
INSERT INTO `kaoqin` VALUES ('1004', '2017-09-26', '0');
INSERT INTO `kaoqin` VALUES ('1004', '2017-09-27', '1');
INSERT INTO `kaoqin` VALUES ('1004', '2017-09-28', '1');
INSERT INTO `kaoqin` VALUES ('1004', '2017-10-11', '1');
INSERT INTO `kaoqin` VALUES ('1005', '2017-09-12', '1');
INSERT INTO `kaoqin` VALUES ('1005', '2017-09-24', '1');
INSERT INTO `kaoqin` VALUES ('1005', '2017-09-26', '1');
INSERT INTO `kaoqin` VALUES ('1005', '2017-09-27', '0');
INSERT INTO `kaoqin` VALUES ('1005', '2017-09-28', '1');
INSERT INTO `kaoqin` VALUES ('1005', '2017-10-11', '1');
INSERT INTO `kaoqin` VALUES ('1006', '2017-09-12', '0');
INSERT INTO `kaoqin` VALUES ('1006', '2017-09-24', '1');
INSERT INTO `kaoqin` VALUES ('1006', '2017-09-26', '1');
INSERT INTO `kaoqin` VALUES ('1006', '2017-09-27', '0');
INSERT INTO `kaoqin` VALUES ('1006', '2017-09-28', '1');
INSERT INTO `kaoqin` VALUES ('1006', '2017-10-11', '1');

-- ----------------------------
-- Table structure for staff
-- ----------------------------
DROP TABLE IF EXISTS `staff`;
CREATE TABLE `staff` (
  `staffid` varchar(255) NOT NULL,
  `staffname` varchar(255) DEFAULT NULL,
  `entrytime` varchar(255) DEFAULT NULL,
  `departmentid` varchar(255) DEFAULT NULL,
  `salary` double DEFAULT NULL,
  `sex` varchar(255) DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `remark` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`staffid`),
  KEY `departmentid` (`departmentid`),
  CONSTRAINT `staff_ibfk_1` FOREIGN KEY (`departmentid`) REFERENCES `department` (`departmentid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of staff
-- ----------------------------
INSERT INTO `staff` VALUES ('1001', '任精湛', '2017-09-04', '101', '160', '男', '22', '上海市川沙翔川家园', '我不管，我最帅，我是你们的小可爱！');
INSERT INTO `staff` VALUES ('1002', '李恒', '2010-06-08', '102', '260', '男', '27', '开封市农机岗', '踏实能干');
INSERT INTO `staff` VALUES ('1003', '李曼', '2017-09-01', '101', '260', '女', '48', '开封市公园路9号', '老板娘');
INSERT INTO `staff` VALUES ('1004', '任东浩', '2017-09-02', '101', '500', '男', '45', '开封市公园路9号', '老板');
INSERT INTO `staff` VALUES ('1005', '李发', '2017-09-04', '102', '260', '男', '25', '暂无', '11111654654313');
INSERT INTO `staff` VALUES ('1006', '岳兆丰', '2017-09-01', '102', '260', '女', '24', '', '');

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `userName` varchar(255) NOT NULL,
  `password` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`userName`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES ('123', '123');
