package com.ren.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ren.mapper.DepartmentMapper;
import com.ren.model.Department;
import com.ren.service.DepartmentService;
import com.ren.util.PageInfo;
import com.ren.util.ValueUtil;

@Service
public class DepartmentServiceImpl implements DepartmentService {

	@Autowired
	private DepartmentMapper departmentMapper;
	
	
	public PageInfo<Department> getDepartments(String name, String pageNo) {
		List<Department> allDepartments=departmentMapper.getAllDepartment(name);
		PageInfo<Department> page=new PageInfo<Department>(pageNo);
		List<Department> departments=departmentMapper.getDepartmentByNameLike(name, page.getPageBegin(), page.getPageSize());
		page.setRowCount(allDepartments.size());
		page.setPageData(departments);
		page.setPageCount(page.getRowCount()%page.getPageSize()==0? page.getRowCount()/page.getPageSize() : (page.getRowCount()/page.getPageSize())+1);
		return page;
	}
	public String deleteDepartment(String departmentid) {
		departmentMapper.deleteDepartment(departmentid);
		if (departmentMapper.selectDepartmentById(departmentid) == null) {
			return ValueUtil.SUCCESS;
		}
		return ValueUtil.FAILURE;
	}
	public String saveDepartment(Department department) {
		Department result=departmentMapper.selectDepartmentById(department.getDepartmentid());
		if(result!=null){
			return "已存在编号为"+department.getDepartmentid()+"的部门信息";
		}else{
			departmentMapper.saveDepartment(department);
		}
		
		return ValueUtil.SUCCESS;
	}

}
