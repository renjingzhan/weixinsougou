package com.ren.service;

import com.ren.model.Department;
import com.ren.util.PageInfo;

public interface DepartmentService {

	public PageInfo<Department> getDepartments(String name,String pageNo);

	public String deleteDepartment(String staffid);

	public String saveDepartment(Department department);
}
