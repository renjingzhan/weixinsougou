package com.ren.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.ren.bmodel.BStaffKaoQin;
import com.ren.model.StaffKaoQin;
import com.ren.service.KaoQinService;

@Controller
@RequestMapping("kaoqin")
public class KaoQinController {

	@Autowired
	private KaoQinService kaoqinService;
	
	@RequestMapping("getStaffKaoQinByDay")
	public void getStaffKaoQinByDay(HttpServletRequest request, HttpServletResponse response) throws IOException{
		String day=request.getParameter("day");
		List<BStaffKaoQin> list=kaoqinService.getStaffKaoQinByDay(day);
		response.setCharacterEncoding("utf-8");
		response.getWriter().write(JSONArray.toJSONString(list));
	}
	
	@RequestMapping("saveDayKaoQin")
	@SuppressWarnings("unchecked")
	public void saveDayKaoQin(HttpServletRequest request, HttpServletResponse response) throws IOException{
		String jsonInfo=request.getParameter("info");
		JSONObject object=JSONObject.parseObject(jsonInfo);
		List<JSONObject> list=(List<JSONObject>)JSONArray.parse(object.get("list").toString());
		List<StaffKaoQin> kaoqins=new ArrayList<StaffKaoQin>();
		for (JSONObject jsonObject : list) {
			StaffKaoQin staff=new StaffKaoQin();
			staff.setStaffid(jsonObject.getString("staffid"));
			staff.setDay(jsonObject.getString("day"));
			String isonduty=jsonObject.getString("isonduty");
			if(isonduty.equals("false")){
				staff.setIsonduty(0);
			}else if(isonduty.equals("true")){
				staff.setIsonduty(1);
			}
			kaoqins.add(staff);
		}
		String result=kaoqinService.saveStaffKaoQin(kaoqins); 
		response.getWriter().write(result);
	}
}
