package com.ren.service;

import java.util.List;

import com.ren.bmodel.BStaff;
import com.ren.model.Department;
import com.ren.util.PageInfo;

public interface StaffService {

	public PageInfo<BStaff> getStaffs(String name,String pageNo);

	public String checkStaffid(String staffid);

	public List<Department> getAllDepartment(String name);

	public String saveStaff(BStaff bstaff);

	public BStaff getStaffById(String staffid);

	public String updateStaff(BStaff bstaff);

	public String deleteStaff(String staffid);
}
