package com.ren.converter;

import org.springframework.core.convert.converter.Converter;

import com.ren.bmodel.BStaff;
import com.ren.model.Staff;

public class StaffConverter implements Converter<BStaff, Staff>{
	
	private static StaffConverter instance;
	
	public static StaffConverter getInstance(){
		if(instance==null){
			return new StaffConverter();
		}
		return instance;
	}

	public Staff convert(BStaff bstaff) {
		Staff staff = new Staff();
		staff.setStaffid(bstaff.getStaffid());
		staff.setStaffname(bstaff.getStaffname());
		staff.setAge(bstaff.getAge());
		staff.setAddress(bstaff.getAddress());
		staff.setEntrytime(bstaff.getEntrytime());
		staff.setSalary(bstaff.getSalary());
		staff.setSex(bstaff.getSex());
		staff.setRemark(bstaff.getRemark());
		return staff;
	}

}
