package com.ren.model;

public class StaffKaoQin {

	private String staffid;
	private String day;
	private Integer isonduty;
	public String getStaffid() {
		return staffid;
	}
	public void setStaffid(String staffid) {
		this.staffid = staffid;
	}
	public String getDay() {
		return day;
	}
	public void setDay(String day) {
		this.day = day;
	}
	public Integer getIsonduty() {
		return isonduty;
	}
	public void setIsonduty(Integer isonduty) {
		this.isonduty = isonduty;
	}
	
	
}
