package com.ren.mapper;

import com.ren.model.DailyCommit;

public interface DailyCommitMapper {

	public DailyCommit selectByDay(String day);
	
	public void addInfo(DailyCommit dailyCommit);
}
