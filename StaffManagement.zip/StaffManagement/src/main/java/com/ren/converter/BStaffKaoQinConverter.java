package com.ren.converter;

import org.springframework.core.convert.converter.Converter;

import com.ren.bmodel.BStaffKaoQin;
import com.ren.model.StaffKaoQin;

public class BStaffKaoQinConverter implements Converter<StaffKaoQin, BStaffKaoQin> {

	private static BStaffKaoQinConverter instance;

	public static BStaffKaoQinConverter getInstance() {
		if (instance == null) {
			return new BStaffKaoQinConverter();
		}
		return instance;
	}

	public BStaffKaoQin convert(StaffKaoQin staffkaoqin) {
		BStaffKaoQin bStaffKaoQin=new BStaffKaoQin();
		bStaffKaoQin.setStaffid(staffkaoqin.getStaffid());
		bStaffKaoQin.setDay(staffkaoqin.getDay());
		bStaffKaoQin.setIsonduty(staffkaoqin.getIsonduty());
		return bStaffKaoQin;	
	}

}
