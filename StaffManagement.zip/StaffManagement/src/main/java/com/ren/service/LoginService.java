package com.ren.service;

import com.ren.model.User;

public interface LoginService {
	
	public String login(User user);
}
