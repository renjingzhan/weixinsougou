loadKaoQin=function(){
	var date=$("#dateSearchButton").val();
	
	if(date==""||date==null){
		Date.prototype.format = function(fmt) { 
		     var o = { 
		        "M+" : this.getMonth()+1,                 // 月份
		        "d+" : this.getDate(),                    // 日
		        "h+" : this.getHours(),                   // 小时
		        "m+" : this.getMinutes(),                 // 分
		        "s+" : this.getSeconds(),                 // 秒
		        "q+" : Math.floor((this.getMonth()+3)/3), // 季度
		        "S"  : this.getMilliseconds()             // 毫秒
		    }; 
		    if(/(y+)/.test(fmt)) {
		            fmt=fmt.replace(RegExp.$1, (this.getFullYear()+"").substr(4 - RegExp.$1.length)); 
		    }
		     for(var k in o) {
		        if(new RegExp("("+ k +")").test(fmt)){
		             fmt = fmt.replace(RegExp.$1, (RegExp.$1.length==1) ? (o[k]) : (("00"+ o[k]).substr((""+ o[k]).length)));
		         }
		     }
		    return fmt; 
		}
		date=new Date().format("yyyy-MM-dd");
		$("#dateSearchButton").val(date);
	}
	$.ajax({
		url:'/StaffManagement/kaoqin/getStaffKaoQinByDay',
		data:{
			"day":date
		},
		datatype : "json",
		success:function(data){
			var html = "<tbody>";
			$.each(JSON.parse(data),function(index,staffKaoQin){
				html += '<tr><td class="t_6" name="staffid">'
					+ staffKaoQin.staffid
					+ '</td><td class="t_6" name="staffname">'
					+ staffKaoQin.staffname
					+ '</td><td class="t_6" name="day">'
					+ staffKaoQin.day
					+ '</td>';
				if(staffKaoQin.isonduty==0){
					html+='<td class="t_6" name="isonduty" ><input id="isonduty" type="checkbox" ></td>'
				}else{
					html+='<td class="t_6" name="isonduty"><input id="isonduty" type="checkbox" checked="checked" ></td>'
				}
				html += '</tr>';
			})
			html+='</tbody>';
			$('#staffKaoQinTable').html(html);
		}
	})
}

commit=function(){
	var result='{"list":['
	$.each($('#staffKaoQinTable').children().children(),function(index,tr){
		var jsonStr='';  
		var staffid='',
		staffname='',
		day='',
		isonduty='';
		$.each($(tr).children(),function(index,td){
			if($(td).attr('name')=="staffid"){
				staffid=$(td).text();
			}
			if($(td).attr('name')=="staffname"){
				staffname=$(td).text();
			}
			if($(td).attr('name')=="day"){
				day=$(td).text();
			}
			if($(td).attr('name')=="isonduty"){
				isonduty=$(td).children("input")[0].checked;
			}
		})
		if(index==0){
			jsonStr='{"staffid":"'+staffid+'","staffname":"'+staffname+'","day":"'+day+'","isonduty":"'+isonduty+'"}';
		}else{
			jsonStr=',{"staffid":"'+staffid+'","staffname":"'+staffname+'","day":"'+day+'","isonduty":"'+isonduty+'"}';
		}
		result+=jsonStr;
	})
	result+=']}';
	
	JSON.parse(result);
	
	$.ajax({
		url:'/StaffManagement/kaoqin/saveDayKaoQin',
		data:{
			"info":result
		},
		//type:'json',
		success:function(data){
			if(data=='success'){
				alert('信息已提交！')
				loadKaoQin();
			}
		}
	})
	
}