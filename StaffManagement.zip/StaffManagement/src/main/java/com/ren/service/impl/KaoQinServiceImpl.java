package com.ren.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ren.bmodel.BStaffKaoQin;
import com.ren.converter.BStaffKaoQinConverter;
import com.ren.mapper.DailyCommitMapper;
import com.ren.mapper.StaffKaoQinMapper;
import com.ren.mapper.StaffMapper;
import com.ren.model.DailyCommit;
import com.ren.model.Staff;
import com.ren.model.StaffKaoQin;
import com.ren.service.KaoQinService;
import com.ren.util.ValueUtil;

@Service
public class KaoQinServiceImpl implements KaoQinService {

	@Autowired
	private StaffKaoQinMapper staffKaoQinMapper;

	@Autowired
	private StaffMapper staffMapper;

	@Autowired
	private DailyCommitMapper dailyCommitMapper;

	public List<BStaffKaoQin> getStaffKaoQinByDay(String day) {
		List<BStaffKaoQin> result = new ArrayList<BStaffKaoQin>();
		List<StaffKaoQin> list = staffKaoQinMapper.getStaffKaoQinsByDay(day);
		List<Staff> staffs = staffMapper.getAllStaffs("");
		for (Staff staff : staffs) {
			BStaffKaoQin bstaffKaoQin = new BStaffKaoQin();
			bstaffKaoQin.setStaffid(staff.getStaffid());
			bstaffKaoQin.setStaffname(staff.getStaffname());
			bstaffKaoQin.setIsonduty(0);
			for (StaffKaoQin staffKaoQin : list) {
				if (staffKaoQin.getStaffid().equals(staff.getStaffid())) {
					bstaffKaoQin.setIsonduty(staffKaoQin.getIsonduty() == null ? 0 : staffKaoQin.getIsonduty());
				}
			}
			bstaffKaoQin.setDay(day);
			result.add(bstaffKaoQin);
		}
		return result;
	}

	public String saveStaffKaoQin(List<StaffKaoQin> kaoqins) {
		String day = kaoqins.get(0).getDay();
		DailyCommit dailyCommit = dailyCommitMapper.selectByDay(day);

		if (dailyCommit == null) {
			DailyCommit commit = new DailyCommit();
			commit.setDay(day);
			commit.setIscommit(1);
			dailyCommitMapper.addInfo(commit);
		}

		for (StaffKaoQin staffKaoQin : kaoqins) {
			StaffKaoQin staff = staffKaoQinMapper.getStaffKaoQin(staffKaoQin.getStaffid(), staffKaoQin.getDay());
			if (staff == null) {
				staffKaoQinMapper.addStaffKaoQin(staffKaoQin);
			} else {
				staffKaoQinMapper.updateStaffKaoQin(staffKaoQin);
			}
		}
		return ValueUtil.SUCCESS;
	}

}
