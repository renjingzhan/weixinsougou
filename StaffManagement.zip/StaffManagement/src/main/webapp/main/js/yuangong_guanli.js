$(function() {
	getDepartments();
	hideAllError();
});

function hideAllError() {
	$('.error,.errorBox').hide();
}

loadStaff = function(pageNo) {
	var value = $("#searchButton").val();
	if(pageNo==null){
		 pageNo = $(".pagenumb cur").text();
	}
	$
			.ajax({
				url : "/StaffManagement/staff/loadStaff",
				data : {
					"name" : value,
					"pageNo" : pageNo
				},
				datatype : "json",
				success : function(data) {
					var html = "<tbody>";
					var page = JSON.parse(data);
					$
							.each(
									page.pageData,
									function(index, staff) {
										html += '<tr><td class="t_1">'
												+ staff.staffid
												+ '</td><td class="t_1">'
												+ staff.staffname
												+ '</td><td class="t_3">'
												+ staff.entrytime
												+ '</td><td class="t_3">'
												+ staff.departmentname
												+ '</td><td class="t_3">'
												+ toDecimal2(staff.salary)
												+ '</td><td class="t_4"><div class="btn"><button  class="modify" >修改</button><button  class="delete">删除</button></div></td></tr>'
									});
					html += '</tbody>';
					$('#stafftable').html(html);
					$(".modify")
							.click(
									function() {
										var staffid = $(this).parent().parent()
												.parent().find("td:first")
												.text();
										window.location.href = "/StaffManagement/main/add_staffinfo.jsp?staffid="
												+ staffid;
									});
					$(".delete")
							.click(
									function() {
										var staffid = $(this).parent().parent()
												.parent().find("td:first")
												.text();
										if (confirm("确认删除编号为" + staffid
												+ "的员工数据？")) {
											$
													.ajax({
														url : "/StaffManagement/staff/deleteStaff",
														data : {
															"staffid" : staffid
														},
														datatype : "json",
														success : function(data) {
															if (data == "success") {
																window.location
																		.reload();
															}
														}
													})
										}
									});
					var pageSpanStr='共 <b>'+page.rowCount+'</b> 条 每页 <b>'+page.pageSize+' </b>条   '+page.pageNo+'/'+page.pageCount;
					$("#pageSpan").html(pageSpanStr)
					var pageHtml='';
					if(page.pageNo==1){
						pageHtml+='';
					}else{
						pageHtml+='<button class="pagePre" ><i class="ico-pre">&nbsp;</i>';
					}
					if(page.pageCount<=5){
						for(var i=1;i<=page.pageCount;i++){
							if(page.pageNo==i){
								pageHtml+='<button  class="pagenumb cur">'+i+'</button>';	
							}else{
								pageHtml+='<button  class="pagenumb">'+i+'</button>';	
							}
						}
					}else{
						if(parseInt(page.pageNo)-2<=0){
							for(var i=1;i<=5;i++){
								if(page.pageNo==i){
									pageHtml+='<button  class="pagenumb cur">'+i+'</button>';	
								}else{
									pageHtml+='<button  class="pagenumb">'+i+'</button>';	
								}
							}
						}else{
							if(parseInt(page.pageNo)+2<=page.pageCount){
								for(var i=parseInt(page.pageNo)-2;i<=parseInt(page.pageNo)+2;i++){
									if(page.pageNo==i){
										pageHtml+='<button  class="pagenumb cur">'+i+'</button>';	
									}else{
										pageHtml+='<button  class="pagenumb">'+i+'</button>';	
									}
								}
							}else{
								for(var i=parseInt(page.pageCount)-4;i<=page.pageCount;i++){
									if(page.pageNo==i){
										pageHtml+='<button  class="pagenumb cur">'+i+'</button>';	
									}else{
										pageHtml+='<button  class="pagenumb">'+i+'</button>';	
									}
								}
							}
							
						}
					}
					if(page.pageNo==page.pageCount){
						pageHtml+='';
					}else{
						pageHtml+='<button  class="pagenext"><i class="ico-next">&nbsp;</i></button>';
					}
					$(".pageWrap").html(pageHtml);
					$(".pagePre").click(function(){
						loadStaff(parseInt(page.pageNo)-1);
					});
					$(".pagenumb").click(function(){
						loadStaff($(this).text());
					});
					$(".pagenext").click(function(){
						loadStaff(parseInt(page.pageNo)+1);
					})
				}
			})
}

modifyStaff = function(staffid) {
	if(staffid!=null&&staffid!=''){
		$.ajax({
			url : "/StaffManagement/staff/getStaffById",
			data : {
				"staffid" : staffid
			},
			datatype : "json",
			success : function(data) {
				var staff = JSON.parse(data);
				$('#staffid').val(staff.staffid);
				$('#staffid').attr("disabled", "disabled");
				$('#staffname').val(staff.staffname);
				$('#sexSpan').text(staff.sex);
				if (staff.sex == "男") {
					$("#sex").val("nan");
				} else {
					$("#sex").val("nv");
				}
				$('#age').val(staff.age);
				$('#salary').val(staff.salary);
				$('#departSpan').text(staff.departmentname);
				$("#departmentselect").val(staff.departmentname);
				$('#address').val(staff.address);
				$('#remark').val(staff.remark);
				$('#entrytime').val(staff.entrytime);
			}
		})
	}
}

// 隐藏错误信息
hideidError = function() {
	$('.idError').hide();
}

hideNameError = function() {
	$('.nameError').hide();
}

hideAgeError = function() {
	$('.ageError').hide();
}

hideSalaryError = function() {
	$('.salaryError').hide();
}

// 展示错误信息
checkid = function() {
	var staffid = $('#staffid').val();
	if (staffid == "") {
		$('.idError').show();
		$('#iderrortext').html("员工编号不能为空!");
		$('#iderrortext').attr("hidden", false);
		return false;
	}
	$.ajax({
		url : '/StaffManagement/staff/checkStaffid',
		data : {
			"staffid" : staffid
		},
		success : function(data) {
			if (data == "contain") {
				$('.idError').show();
				$('#iderrortext').html("您所输入的员工编号已存在，请重新输入！");
				$('#iderrortext').attr("hidden", false);
				return false;
			} else {
				$('.idError').hide();
				$('#iderrortext').attr("hidden", true);
				return true;
			}
		}
	})
}

checkName = function() {
	var staffname = $('#staffname').val();
	if (staffname == "") {
		$('.nameError').show();
		return false;
	} else {
		$('.nameError').hide();
		return true;
	}
}

checkSex = function() {
	var sex = $('#sex').val();
	if (sex == "none") {
		$('.sexError').show();
		return false;
	} else {
		$('.sexError').hide();
		return true;
	}
}

checkAge = function() {
	var age = $("#age").val();
	if (age == 0) {
		$('#ageerrortext').html("年龄不能为空！");
		$('.ageError').show();
		return false;
	} else if (age < 0) {
		$('#ageerrortext').html("输入值必须大于0！");
		$('.ageError').show();
		return false;
	} else {
		$('.ageError').hide();
		return true;
	}
}

checkEntryTime = function() {
	var entrytime = $('#entrytime').val();
	if (entrytime == "") {
		$('#entryTimeerrortext').html("入职日期不能为空！");
		$('.entryTimeError').show();
		return false;
	} else if (new Date(entrytime) > new Date()) {
		$('#entryTimeerrortext').html("入职日期不能大于今天！");
		$('.entryTimeError').show();
		return false;
	} else {
		$('.entryTimeError').hide();
		return true;
	}
}

// 部门加载
function getDepartments() {
	$("#departmentselect").empty();
	$.ajax({
		url : '/StaffManagement/staff/getDepartments',
		datatype : 'json',
		success : function(data) {
			var html = '<option value="none" hidden="true">请选择部门</option>';
			$.each(JSON.parse(data), function(index, department) {
				html += '<option value="' + department.departmentname + '">'
						+ department.departmentname + '</option>'
			});
			$("#departmentselect").html(html);
		}
	})

}

departchange = function() {
	var value = $("#departmentselect").children('option:selected').val();
	$("#departSpan").text(value);
}

// 性别选择
sexchange = function() {
	var value = $("#sex").children('option:selected').val();
	if (value == "nan") {
		$("#sexSpan").text("男");
	} else {
		$("#sexSpan").text("女");
	}
}

// 小数位保留
around = function() {
	var inputvalue = $("#salary").val();
	if (inputvalue == "") {
		$('#salaryerrortext').html("薪资不能为空！");
		$('.salaryError').show();
		return false;
	} else if (inputvalue < 0) {
		$('.salaryError').show();
		$('#salaryerrortext').html("输入值必须大于0！");
		return false;
	} else {
		$('.salaryError').hide();
		$("#salary").val(toDecimal2(inputvalue));
		return true;
	}
}

// 制保留2位小数，如：2，会在2后面补上00.即2.00
function toDecimal2(x) {
	var f = parseFloat(x);
	if (isNaN(f)) {
		return "";
	}
	var f = Math.round(x * 100) / 100;
	var s = f.toString();
	var rs = s.indexOf('.');
	if (rs < 0) {
		rs = s.length;
		s += '.';
	}
	while (s.length <= rs + 2) {
		s += '0';
	}
	return s;
}

// 保存员工信息
saveStaff = function() {
	var staffid = $('#staffid').val(), staffname = $('#staffname').val(), sex = $(
			'#sexSpan').text(), age = $('#age').val(), salary = $('#salary')
			.val(), departmentname = $('#departSpan').text(), address = $(
			'#address').val(), remark = $('#remark').val(), entrytime = $(
			'#entrytime').val();

	if (checkAll()) {
		var url = '/StaffManagement/staff/saveStaff';
		if ($('#staffid').attr("disabled") == "disabled") {
			url = '/StaffManagement/staff/updateStaff';
		}
		$
				.ajax({
					url : url,
					data : {
						"staffid" : staffid,
						"staffname" : staffname,
						"sex" : sex,
						"age" : age,
						"salary" : salary,
						"departmentname" : departmentname,
						"address" : address,
						"remark" : remark,
						"entrytime" : entrytime
					},
					success : function(data) {
						if (data == "success") {
							window.location.href = "/StaffManagement/main/yuangong_guanli.jsp";
						}
					}
				})
	}
}

checkAll = function() {
	if (!$('#staffid').attr("disabled") == "disabled") {
		checkid();
	}
	checkName();
	checkAge();
	around();
	if ($('#iderrortext').attr("hidden") == "hidden" && checkName()
			&& checkAge() && around()) {
		if ($("#sex").val() == "none") {
			$('#buttonerrortext').html("请选择性别！");
			$('.buttonError').show();
			return false;
		}
		if ($("#departmentselect").val() == "none") {
			$('#buttonerrortext').html("请选择部门！");
			$('.buttonError').show();
			return false;
		}
		$('.buttonError').hide();
		return true;
	} else {
		return false;
	}
}
