package com.ren.controller;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.alibaba.fastjson.JSONObject;
import com.ren.model.Department;
import com.ren.service.DepartmentService;
import com.ren.util.PageInfo;

@Controller
@RequestMapping("department")
public class DepartmentController {

	@Autowired
	private DepartmentService departmentService;
	
	@RequestMapping("loadDepartment")
	public void loadStaff(HttpServletRequest request,HttpServletResponse response) throws IOException {
		String name=request.getParameter("name");
		String pageNo=request.getParameter("pageNo");
		if(pageNo.equals("")||pageNo==null){
			pageNo="1";
		}
		PageInfo<Department> page = departmentService.getDepartments(name,pageNo);
		response.setCharacterEncoding("utf-8");
		response.getWriter().write(JSONObject.toJSONString(page));
	}
	
	@RequestMapping("deleteDepartment")
	public void deleteStaff(HttpServletRequest request,HttpServletResponse response) throws IOException{
		String departmentid=request.getParameter("departmentid");
		String result=departmentService.deleteDepartment(departmentid);
		response.setCharacterEncoding("utf-8");
		response.getWriter().write(result);
	}
	
	@RequestMapping("saveDepartment")
	public void saveDepartment(HttpServletRequest request,HttpServletResponse response) throws IOException{
		String departmentid=request.getParameter("departmentid");
		String departmentname=request.getParameter("departmentname");
		String duty=request.getParameter("duty");
		Department department=new Department(departmentid,departmentname,duty);
		String result=departmentService.saveDepartment(department);
		response.setCharacterEncoding("utf-8");
		response.getWriter().write(result);
	}
	
	
}
