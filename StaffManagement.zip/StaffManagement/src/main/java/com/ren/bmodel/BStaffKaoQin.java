package com.ren.bmodel;

import com.ren.model.StaffKaoQin;

public class BStaffKaoQin extends StaffKaoQin{

	private String staffname;

	public String getStaffname() {
		return staffname;
	}

	public void setStaffname(String staffname) {
		this.staffname = staffname;
	}
	
}
