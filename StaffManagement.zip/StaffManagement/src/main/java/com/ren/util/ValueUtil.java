package com.ren.util;

public class ValueUtil {

	public static final String SUCCESS="success";
	public static final String FAILURE="failure";
	public static final String CONTAIN="contain";
	public static final String UNCONTAIN="uncontain";
}
