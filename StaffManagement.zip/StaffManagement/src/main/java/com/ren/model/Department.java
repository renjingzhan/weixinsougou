package com.ren.model;

public class Department {

	private String departmentid;
	private String departmentname;
	private String duty;
	public String getDepartmentid() {
		return departmentid;
	}
	public void setDepartmentid(String departmentid) {
		this.departmentid = departmentid;
	}
	public String getDepartmentname() {
		return departmentname;
	}
	public void setDepartmentname(String departmentname) {
		this.departmentname = departmentname;
	}
	public String getDuty() {
		return duty;
	}
	public void setDuty(String name) {
		this.duty = name;
	}
	public Department(String departmentid, String departmentname, String duty) {
		super();
		this.departmentid = departmentid;
		this.departmentname = departmentname;
		this.duty = duty;
	}
	public Department() {
		super();
	}
	
	
}
