package com.ren.mapper;

import java.util.List;

import com.ren.model.StaffKaoQin;

public interface StaffKaoQinMapper {

	public List<StaffKaoQin> getStaffKaoQinsByDay(String date);
	
	public void addStaffKaoQin(StaffKaoQin staffKaoQin);
	
	public void updateStaffKaoQin(StaffKaoQin staffKaoQin);
	
	public StaffKaoQin getStaffKaoQin(String staffid,String day);
}
