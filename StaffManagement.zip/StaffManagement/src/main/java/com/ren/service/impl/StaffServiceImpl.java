package com.ren.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ren.bmodel.BStaff;
import com.ren.converter.BStaffConverter;
import com.ren.converter.StaffConverter;
import com.ren.mapper.DepartmentMapper;
import com.ren.mapper.StaffMapper;
import com.ren.model.Department;
import com.ren.model.Staff;
import com.ren.service.StaffService;
import com.ren.util.PageInfo;
import com.ren.util.ValueUtil;

@Service
public class StaffServiceImpl implements StaffService {

	@Autowired
	private StaffMapper staffMapper;

	@Autowired
	private DepartmentMapper departmentMapper;

	public PageInfo<BStaff> getStaffs(String name,String pageNo) {
		List<Staff> staffs = null;
		List<Staff> allStaffs = null;
		List<BStaff> bstaffs = new ArrayList<BStaff>();
		PageInfo<BStaff> page=new PageInfo<BStaff>(pageNo);
		allStaffs = staffMapper.getAllStaffs(name);
		staffs = staffMapper.getStaffsByNameLike(name,page.getPageBegin(),page.getPageSize());
		
		for (Staff staff : staffs) {
			BStaff bstaff = BStaffConverter.getInstance().convert(staff);
			bstaff.setDepartmentname(departmentMapper.getNameById(staff.getDepartmentid()));
			bstaffs.add(bstaff);
		}
		
		page.setRowCount(allStaffs.size());
		page.setPageData(bstaffs);
		page.setPageCount(page.getRowCount()%page.getPageSize()==0? page.getRowCount()/page.getPageSize() : (page.getRowCount()/page.getPageSize())+1);
		return page;

	}

	public String checkStaffid(String staffid) {
		Staff staff = staffMapper.selectStaffById(staffid);
		if (staff != null) {
			return ValueUtil.CONTAIN;
		}
		return ValueUtil.UNCONTAIN;
	}

	public List<Department> getAllDepartment(String name) {

		return departmentMapper.getAllDepartment(name);
	}

	public String saveStaff(BStaff bstaff) {
		Staff staff = StaffConverter.getInstance().convert(bstaff);
		staff.setDepartmentid(departmentMapper.getIdByName(bstaff.getDepartmentname()));
		staffMapper.saveStaff(staff);
		return ValueUtil.SUCCESS;
	}

	public BStaff getStaffById(String staffid) {
		Staff staff = staffMapper.selectStaffById(staffid);
		BStaff bstaff = BStaffConverter.getInstance().convert(staff);
		bstaff.setDepartmentname(departmentMapper.getNameById(staff.getDepartmentid()));
		return bstaff;
	}

	public String updateStaff(BStaff bstaff) {
		Staff staff = StaffConverter.getInstance().convert(bstaff);
		staff.setDepartmentid(departmentMapper.getIdByName(bstaff.getDepartmentname()));
		staffMapper.updateStaff(staff);
		return ValueUtil.SUCCESS;
	}

	public String deleteStaff(String staffid) {
		staffMapper.deleteStaff(staffid);
		if (staffMapper.selectStaffById(staffid) == null) {
			return ValueUtil.SUCCESS;
		}
		return ValueUtil.FAILURE;
	}

}
