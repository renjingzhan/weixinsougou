package com.ren.controller;

import java.io.IOException;
import java.text.DecimalFormat;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.ren.bmodel.BStaff;
import com.ren.model.Department;
import com.ren.service.StaffService;
import com.ren.util.PageInfo;
import com.ren.util.ValueUtil;

@Controller
@RequestMapping("staff")
public class StaffController {

	@Autowired
	private StaffService staffService;
	
	//private DecimalFormat    df   = new DecimalFormat("######0.00");   

	@RequestMapping("loadStaff")
	public void loadStaff(HttpServletRequest request,HttpServletResponse response) throws IOException {
		String name=request.getParameter("name");
		String pageNo=request.getParameter("pageNo");
		if(pageNo.equals("")||pageNo==null){
			pageNo="1";
		}
		PageInfo<BStaff> page = staffService.getStaffs(name,pageNo);
		response.setCharacterEncoding("utf-8");
		response.getWriter().write(JSONObject.toJSONString(page));
	}

	@RequestMapping("checkStaffid")
	public void checkStaffid(HttpServletRequest request, HttpServletResponse response) throws IOException {
		String staffid = request.getParameter("staffid");
		String result = staffService.checkStaffid(staffid);
		response.getWriter().write(result);
	}

	@RequestMapping("getDepartments")
	public void getDepartments(HttpServletResponse response) throws IOException {
		response.setCharacterEncoding("utf-8");
		List<Department> departments = staffService.getAllDepartment("");
		response.getWriter().write(JSONArray.toJSONString(departments));
	}

	@RequestMapping("saveStaff")
	public void saveStaff(HttpServletRequest request, HttpServletResponse response) throws IOException {
		BStaff bstaff = new BStaff();
		bstaff.setStaffid(request.getParameter("staffid"));
		bstaff.setStaffname(request.getParameter("staffname"));
		bstaff.setSex(request.getParameter("sex"));
		bstaff.setAge(Integer.parseInt(request.getParameter("age")));
		bstaff.setAddress(request.getParameter("address"));
		bstaff.setDepartmentname(request.getParameter("departmentname"));
		bstaff.setRemark(request.getParameter("remark"));
		bstaff.setEntrytime(request.getParameter("entrytime"));
		bstaff.setSalary(Double.valueOf(request.getParameter("salary")));
		String result = staffService.saveStaff(bstaff);
		response.getWriter().write(result);
	}
	
	@RequestMapping("updateStaff")
	public void updateStaff(HttpServletRequest request, HttpServletResponse response) throws IOException{
		BStaff bstaff = new BStaff();
		bstaff.setStaffid(request.getParameter("staffid"));
		bstaff.setStaffname(request.getParameter("staffname"));
		bstaff.setSex(request.getParameter("sex"));
		bstaff.setAge(Integer.parseInt(request.getParameter("age")));
		bstaff.setAddress(request.getParameter("address"));
		bstaff.setDepartmentname(request.getParameter("departmentname"));
		bstaff.setRemark(request.getParameter("remark"));
		bstaff.setEntrytime(request.getParameter("entrytime"));
		bstaff.setSalary(Double.valueOf(request.getParameter("salary")));
		String result = staffService.updateStaff(bstaff);
		response.getWriter().write(result);
	}
	
	@RequestMapping("getStaffById")
	public void getStaffById(HttpServletRequest request, HttpServletResponse response) throws IOException{
		String staffid=request.getParameter("staffid");
		BStaff bstaff=staffService.getStaffById(staffid);
		response.setCharacterEncoding("utf-8");
		response.getWriter().write(JSONArray.toJSONString(bstaff));
	}
	
	@RequestMapping("deleteStaff")
	public void deleteStaff(HttpServletRequest request,HttpServletResponse response) throws IOException{
		String staffid=request.getParameter("staffid");
		String result=staffService.deleteStaff(staffid);
		response.setCharacterEncoding("utf-8");
		response.getWriter().write(result);
	}
}
