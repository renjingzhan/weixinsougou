$(function(){
	$(".saveBtn").click(function(){
		var departmentid=$("#idinput").val(),
		departmentname=$("#nameinput").val(),
		duty=$("#dutyinput").val();
		if(departmentid==""){
			alert("部门编号不能为空");
		}else{
			$.ajax({
				url:'/StaffManagement/department/saveDepartment',
				data:{
					"departmentid":departmentid,
					"departmentname":departmentname,
					"duty":duty
				},
				success:function(data){
					if(data=="success"){
						$(".layuiBox").fadeOut();
						window.location.reload();
					}else{
						alert(data);
					}
				}
			})
		}
		
	})
	
})



loadDepartment = function(pageNo) {
	var value = $("#searchButton").val();
	if(pageNo==null){
		 pageNo = $(".pagenumb cur").text();
	}
	$
			.ajax({
				url : "/StaffManagement/department/loadDepartment",
				data : {
					"name" : value,
					"pageNo" : pageNo
				},
				datatype : "json",
				success : function(data) {
					var html = "<tbody>";
					var page = JSON.parse(data);
					$
							.each(
									page.pageData,
									function(index, department) {
										html += '<tr><td class="t_8">'
												+ department.departmentid
												+ '</td><td class="t_8">'
												+ department.departmentname
												+ '</td><td class="t_2_1">'
												+ department.duty
												+ '</td><td class="t_4"><div class="btn"><button  class="delete">删除</button></div></td></tr>'
									});
					html += '</tbody>';
					$('#departmentTable').html(html);
//					$(".modify")
//							.click(
//									function() {
//										var staffid = $(this).parent().parent()
//												.parent().find("td:first")
//												.text();
//										window.location.href = "/StaffManagement/main/add_staffinfo.jsp?staffid="
//												+ staffid;
//									});
					$(".delete")
							.click(
									function() {
										var departmentid = $(this).parent().parent()
												.parent().find("td:first")
												.text();
										if (confirm("确认删除编号为" + departmentid
												+ "的部门数据？")) {
											$
													.ajax({
														url : "/StaffManagement/department/deleteDepartment",
														data : {
															"departmentid" : departmentid
														},
														datatype : "json",
														success : function(data) {
															if (data == "success") {
																window.location
																		.reload();
															}
														}
													})
										}
									});
					var pageSpanStr='共 <b>'+page.rowCount+'</b> 条 每页 <b>'+page.pageSize+' </b>条   '+page.pageNo+'/'+page.pageCount;
					$("#pageSpan").html(pageSpanStr)
					var pageHtml='';
					if(page.pageNo==1){
						pageHtml+='';
					}else{
						pageHtml+='<button class="pagePre" ><i class="ico-pre">&nbsp;</i>';
					}
					if(page.pageCount<=5){
						for(var i=1;i<=page.pageCount;i++){
							if(page.pageNo==i){
								pageHtml+='<button  class="pagenumb cur">'+i+'</button>';	
							}else{
								pageHtml+='<button  class="pagenumb">'+i+'</button>';	
							}
						}
					}else{
						if(parseInt(page.pageNo)-2<=0){
							for(var i=1;i<=5;i++){
								if(page.pageNo==i){
									pageHtml+='<button  class="pagenumb cur">'+i+'</button>';	
								}else{
									pageHtml+='<button  class="pagenumb">'+i+'</button>';	
								}
							}
						}else{
							if(parseInt(page.pageNo)+2<=page.pageCount){
								for(var i=parseInt(page.pageNo)-2;i<=parseInt(page.pageNo)+2;i++){
									if(page.pageNo==i){
										pageHtml+='<button  class="pagenumb cur">'+i+'</button>';	
									}else{
										pageHtml+='<button  class="pagenumb">'+i+'</button>';	
									}
								}
							}else{
								for(var i=parseInt(page.pageCount)-4;i<=page.pageCount;i++){
									if(page.pageNo==i){
										pageHtml+='<button  class="pagenumb cur">'+i+'</button>';	
									}else{
										pageHtml+='<button  class="pagenumb">'+i+'</button>';	
									}
								}
							}
							
						}
					}
					if(page.pageNo==page.pageCount){
						pageHtml+='';
					}else{
						pageHtml+='<button  class="pagenext"><i class="ico-next">&nbsp;</i></button>';
					}
					$(".pageWrap").html(pageHtml);
					$(".pagePre").click(function(){
						loadStaff(parseInt(page.pageNo)-1);
					});
					$(".pagenumb").click(function(){
						loadStaff($(this).text());
					});
					$(".pagenext").click(function(){
						loadStaff(parseInt(page.pageNo)+1);
					})
				}
			})
}


