package com.ren.mapper;

import java.util.List;

import com.ren.model.Staff;

public interface StaffMapper {

	public List<Staff> getAllStaffs(String name);

	public Staff selectStaffById(String staffid);
	
	public void saveStaff(Staff staff);

	public void updateStaff(Staff staff);

	public void deleteStaff(String staffid);

	public List<Staff> getStaffsByNameLike(String name,int pageBegin,int pageEnd);
}
