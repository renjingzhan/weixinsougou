package com.ren.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.ren.model.User;
import com.ren.service.LoginService;
import com.ren.util.ValueUtil;

@Controller
@RequestMapping("/login")
public class LoginController {
	
	@Autowired
	private LoginService loginService;
	
	@RequestMapping("/checkUser")
	public ModelAndView login(HttpServletRequest request,Model model){
		String userName=request.getParameter("username");
		String password=request.getParameter("password");
		
		String result=loginService.login(new User(userName,password));
		if(result.equals(ValueUtil.SUCCESS)){
			return new ModelAndView("/main/main");
		}
		model.addAttribute("failMessage","�û����������,�����µ�½��");
		return new ModelAndView("/login/login");
	}
}
