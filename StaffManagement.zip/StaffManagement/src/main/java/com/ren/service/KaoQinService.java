package com.ren.service;

import java.util.List;

import com.ren.bmodel.BStaffKaoQin;
import com.ren.model.StaffKaoQin;

public interface KaoQinService {

	public List<BStaffKaoQin> getStaffKaoQinByDay(String day);

	public String saveStaffKaoQin(List<StaffKaoQin> kaoqins);
}
