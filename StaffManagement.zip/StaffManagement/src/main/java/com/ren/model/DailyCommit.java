package com.ren.model;

public class DailyCommit {

	private String day;
	private Integer iscommit;
	public String getDay() {
		return day;
	}
	public void setDay(String day) {
		this.day = day;
	}
	public Integer getIscommit() {
		return iscommit;
	}
	public void setIscommit(Integer iscommit) {
		this.iscommit = iscommit;
	}
	
	
}
