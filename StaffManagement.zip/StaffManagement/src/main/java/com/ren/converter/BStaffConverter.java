package com.ren.converter;

import org.springframework.core.convert.converter.Converter;

import com.ren.bmodel.BStaff;
import com.ren.model.Staff;

public class BStaffConverter implements Converter<Staff, BStaff>{

	private static BStaffConverter instance;
	
	public static BStaffConverter getInstance(){
		if(instance==null){
			return new BStaffConverter();
		}
		return instance;
	}
	
	public BStaff convert(Staff staff) {
		BStaff bstaff = new BStaff();
		bstaff.setStaffid(staff.getStaffid());
		bstaff.setStaffname(staff.getStaffname());
		bstaff.setAge(staff.getAge());
		bstaff.setAddress(staff.getAddress());
		bstaff.setEntrytime(staff.getEntrytime());
		bstaff.setSalary(staff.getSalary());
		bstaff.setSex(staff.getSex());
		bstaff.setRemark(staff.getRemark());
		return bstaff;
	}

}
