package com.ren.mapper;

public interface UserMapper {

	public String getPasswordByName(String userName);
}
