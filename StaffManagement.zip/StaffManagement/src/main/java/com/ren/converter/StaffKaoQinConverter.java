package com.ren.converter;

import org.springframework.core.convert.converter.Converter;

import com.ren.bmodel.BStaffKaoQin;
import com.ren.model.StaffKaoQin;

public class StaffKaoQinConverter  implements Converter<BStaffKaoQin, StaffKaoQin>{
	private static StaffKaoQinConverter instance;

	public static StaffKaoQinConverter getInstance() {
		if (instance == null) {
			return new StaffKaoQinConverter();
		}
		return instance;
	}
	
	public StaffKaoQin convert(BStaffKaoQin bStaffKaoQin) {
		StaffKaoQin staffKaoQin=new StaffKaoQin();
		staffKaoQin.setStaffid(bStaffKaoQin.getStaffid());
		staffKaoQin.setDay(bStaffKaoQin.getDay());
		staffKaoQin.setIsonduty(bStaffKaoQin.getIsonduty());
		return staffKaoQin;
	}

}
